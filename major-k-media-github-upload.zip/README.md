# Major K Media

A responsive photography site for Major K Media in McAlester, Oklahoma. The design uses an asymmetrical photo layout, Bodoni Moda typography, a warm beige palette, charcoal accents, and direct call/text contact actions.

## Updating the photographs and packages

All gallery photos and package fields are grouped in `dist/content.js`.

- Put Major K Media's photographs in `dist/assets/photos/` and update the matching `src` and descriptive `alt` values.
- Set each approved photograph's `isPlaceholder` to `false`. Its placeholder label then updates automatically. The preview disclosure disappears once all photographs are approved.
- Update `position` to control an image's crop inside its frame. This uses ordinary CSS `object-position` values such as `50% 30%`.
- Update each package placeholder's `name`, `description`, `packageName`, `price`, `coverage`, and `included` fields when confirmed, then set `isPlaceholder` to `false`. The `price` is a display string, so it can be an exact price or an approved starting price. No currency values are invented.
- The `showcase` array contains the gallery titles and subtitles. Replace the coming-soon text when the actual portfolio is added.
- The showcase introduction and main page wording are in `dist/index.html`. Update its coming-soon introduction once the real work is ready.

The phone number is `(918) 424-7033`. All call links use `tel:+19184247033`; the text button uses `sms:+19184247033`. These open the visitor's phone or messaging app. The site does not submit a booking or send a message itself.

The current review version has a brief logo intro, scroll-position protection, `noindex, nofollow` metadata, and a restrictive robots file because photographs, prices, and package details are placeholders. Remove the review-only indexing directives when the business approves a public launch. No fake reviews, credentials, availability, prices, biography, social links, or booking confirmations are included.

## Files

`dist/` is a complete, portable static website. It contains its own fonts and images and can be hosted as-is; no dependency install or build step is required. Keep `index.html`, `styles.css`, `content.js`, `app.js`, and the `assets/` directory together.

The page includes keyboard-accessible native package accordions, mobile navigation that supports Escape and outside-click dismissal, reduced-motion support, image loading fallbacks, and direct contact links.

## Research and credits

See `DESIGN-REFERENCES.md` for the photography sites reviewed and the design reasoning. `ASSET-CREDITS.md` records the supplied preview imagery, cleaned logo, and font licenses.
